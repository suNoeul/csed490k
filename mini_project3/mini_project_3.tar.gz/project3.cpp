#include<stdio.h>
#include<stdlib.h>
#include <mpi.h>


int main(int argc, char* argv[]) {

}